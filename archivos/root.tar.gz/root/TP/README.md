# Trabajo Práctico Integrador - Computación Aplicada

# Profesor:

# Lic. Pablo Ferro


# Integrantes del grupo:

# Janet Molina
# Natalia Jacofsky
# Kevin Alexander Martinez Montalvo
# Lisandro Brizuela 
