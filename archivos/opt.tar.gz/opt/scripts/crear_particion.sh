#!/bin/sh
cat /proc/partitions > /root/particion
