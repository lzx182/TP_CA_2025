#! /bin/bash

if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 origen destino"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi
if [[ $# -ne 2 ]]; then
	echo "Error. Indique el directorio de origen y destino."
	echo "Usa -help para más información."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen '$ORIGEN' no existe."
	exit 1
fi
if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio de destino '$DESTINO' no existe."
	exit 1
fi

echo "Creando backup de $ORIGEN en $DESTINO/$ARCHIVO..."
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [[ $? -eq 0 ]]; then
	echo "Backup completado exitosamente."
else
	echo "Error al crear el backup."
fi
